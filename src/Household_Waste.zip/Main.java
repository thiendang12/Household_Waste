


import controller.HouseholdWasteController;


public class Main {
    public static void main(String[] args) {
        HouseholdWasteController manager = new HouseholdWasteController();
        manager.run();
    }
}
